const express = require('express');
const http = require('http');
const socketIo = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// Middleware to parse JSON payloads
app.use(express.json());

// Webhook endpoint to receive GitHub push events
app.post('/webhook', (req, res) => {
    console.log('Push event received:', req.body);

    // Emit the push event to connected clients (Unity)
    io.emit('push-event', req.body);

    // Respond to GitHub
    res.status(200).send('Webhook received');
});

// Handle socket connection
io.on('connection', (socket) => {
    console.log('Unity client connected');

    socket.on('disconnect', () => {
        console.log('Unity client disconnected');
    });
});

// Start the server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Notification relay server running on port ${PORT}`);
});
